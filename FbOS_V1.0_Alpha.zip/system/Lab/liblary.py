import os

def lab(lab_1,lab_2):
    
        with open("text.dll",'r') as lb:

            print("[source]")
            print("source file = lab/lab.sys")
            print("source .info file = lab/lab.info")
            print("package file = lab/lab, lab/lab.1, lab/lab.2, lab/sys.lab")
            
            lb.close()

        os.link("lab/lab.html")
        os.read("lab/lab.dll")
        os.read("lab/lab.html")

        
