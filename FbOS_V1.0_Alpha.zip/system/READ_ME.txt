this is a alpha version of FreeBasic OS.

What's add:
- Unfunctional menu.
- Digital Clock.
- Name tag Version.

t.me\@SkyFerest_Channel
x.com\@SkyFerest17