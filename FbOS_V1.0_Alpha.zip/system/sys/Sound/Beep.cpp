#include "windows.h"
#include <iostream>
using namespace std;

int main(){
	Beep(987,100);
	cin.get();
	return 0;
}
